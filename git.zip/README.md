# Project Iceberg

**Discovery of PowerLogInv and computational census of continuous Sheffer operator families**

Odrzywołek (2026) showed that `eml(x,y) = exp(x) - ln(y)` is a continuous analogue of the NAND gate — a single binary operator that generates all elementary functions. We discover a new Sheffer operator:

    pli(x,y) = ln(x)^(1/y)    (companion constant: 1)

and prove it is non-equivalent to all known operators. A computational census of 14,712 verification runs across two structural levels finds exactly three operator families: EML, EDL, and PLI.

## Key Results

| Result | Detail |
|--------|--------|
| New operator | PowerLogInv: ln(x)^(1/y) |
| Non-equivalence | Proven under T1-T5 (Theorem 1) |
| Census | 14,712 runs, 3 families, no 4th |
| Depth hierarchy | Sheffer at depth 1-2 only |
| 13/35 barrier | exp/ln bridge is necessary |
| Theoretical foundation | exp/ln necessity proven via Liouville-Ritt tower |

## Paper

- arXiv: *link TBD*
- PDF: [paper/main.pdf](paper/main.pdf)

## Repository Structure

    project-iceberg/
    ├── README.md
    ├── LICENSE
    ├── REPRODUCE.md
    ├── CITATION.cff
    ├── paper/
    │   ├── main.tex
    │   └── main.pdf
    ├── src/
    │   ├── rust_engine/           # forked Rust verifier
    │   ├── enumerator/            # Python candidate enumeration
    │   ├── analysis/              # SymPy verification, benchmarks
    │   └── search/                # search orchestration scripts
    └── results/
        ├── verify_L1_results.csv
        ├── verify_L2_stage2.log
        ├── candidates_L1.json
        ├── candidates_L2.json
        ├── stability_four_ops.csv
        ├── cost/
        └── analysis/

## Reproduction

See [REPRODUCE.md](REPRODUCE.md) for step-by-step instructions.

## Citation

    @article{jeong2026powerloginv,
      title   = {PowerLogInv: A New Sheffer-Type Operator for
                 Elementary Functions and a Computational Census
                 of Operator Families},
      author  = {Jeong, SangHyeok},
      journal = {arXiv preprint},
      year    = {2026}
    }

## Acknowledgments

Built upon the foundational work of Andrzej Odrzywołek
([arXiv:2603.21852](https://arxiv.org/abs/2603.21852))
and his open-source verification engine
([SymbolicRegressionPackage](https://github.com/VA00/SymbolicRegressionPackage)).

## License

See [LICENSE](LICENSE) file.
