# Reproduction Guide

## Prerequisites

- Rust 1.94+ (for verification engine)
- Python 3.10+ (for enumeration and analysis)
- Python packages: mpmath, sympy, numpy

## Step 1: Build the Rust verifier

    cd src/rust_engine
    cargo build --release

## Step 2: Reproduce EML verification

    ./target/release/rust_verify --op EML --const 1 --kmax 9

Expected: 35/35 targets found in ~37s.

## Step 3: Reproduce PLI verification

    ./target/release/rust_verify --custom-op "PLI:Power(Log(x),Inv(y))" --const 1 --kmax 9

Expected: 35/35 targets found in ~38s.

## Step 4: Level 1 full census

    python src/enumerator/level1.py | \
      xargs -P 8 -I {} ./target/release/rust_verify {}

Expected: 14,077 runs, 4 Sheffer hits (2 PLI + 2 DLE-equiv).

## Step 5: Level 2 census

    python src/enumerator/level2.py --filter | \
      xargs -P 8 -I {} ./target/release/rust_verify {}

Expected: 635 runs after filtering, 10 Sheffer hits (all equivalent to known families).

## Step 6: Numerical stability benchmark

    python src/analysis/stability_benchmark.py

Expected: Generates stability_four_ops.csv matching results/ directory.

## Verification

All results should match the files in the results/ directory exactly. The pipeline is fully deterministic given the same operator definition, constant set, K_max, evaluation points, numerical precision, and tolerance threshold. No randomized components are used.

## Hardware

Original results were produced on:
- CPU: AMD Ryzen 9 9950X3D
- OS: Windows 11
- Rust: 1.94.1 (release build, opt-level=3)

Timing results may differ on other hardware, but target counts and Sheffer hit counts are deterministic and should be identical.
